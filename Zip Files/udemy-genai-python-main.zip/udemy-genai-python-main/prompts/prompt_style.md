# Prompt Styles

## Alpaca Prompt

### Instructions: <SYSTEM_PROMPT>\n

### Input: <USER_QUERY>

### Response:\n

# ChatML

{
"role": "system" | "user" | "assistant"
"content": "string"
}

# INST Prompting

[INST] What is the time now? [/INST]
