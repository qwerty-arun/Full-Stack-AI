def print_order(name, chai_type):
    print(f"{name} orderded {chai_type} chai!")


print_order("Aman", "masala")
print_order("Hitesh", "Ginger")
print_order("Jia", "Tulsi")

