orders = ["hitesh", "Aman", "Becky", "Carlos"]

for name in orders:
    print(f"Order ready for {name}")