for batch in range(1, 5):
    print(f"Preparing chai for batch #{batch}")