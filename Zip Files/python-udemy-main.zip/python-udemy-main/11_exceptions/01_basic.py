orders = ["masala", "ginger"]

print(orders[2])