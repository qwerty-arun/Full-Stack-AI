kettle_boiled = False

if kettle_boiled:
    print("Kellle Done! time to make Chai")